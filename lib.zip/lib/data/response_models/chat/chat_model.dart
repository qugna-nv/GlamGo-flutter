class ChatMessageModel {
  final int id;
  final int userId;
  final int? adminId;
  final String message;
  final bool isAdmin;
  final String? senderName;
  final String? createdAt;

  ChatMessageModel({
    required this.id,
    required this.userId,
    this.adminId,
    required this.message,
    required this.isAdmin,
    this.senderName,
    this.createdAt,
  });

  factory ChatMessageModel.fromJson(Map<String, dynamic> json) {
    return ChatMessageModel(
      id: _intValue(json['id']),
      userId: _intValue(json['user_id']),
      adminId: json['admin_id'] == null ? null : _intValue(json['admin_id']),
      message: json['message']?.toString() ?? '',
      isAdmin: json['is_admin'] == true || json['is_admin'] == 1,
      senderName: json['sender_name']?.toString(),
      createdAt: json['created_at']?.toString(),
    );
  }

  static int _intValue(dynamic value) {
    if (value is num) return value.toInt();
    return int.tryParse(value?.toString() ?? '') ?? 0;
  }
}

class ChatThreadModel {
  final String channel;
  final List<ChatMessageModel> messages;

  ChatThreadModel({
    required this.channel,
    required this.messages,
  });

  factory ChatThreadModel.fromJson(Map<String, dynamic> json) {
    final messages = json['messages'] as List<dynamic>? ?? [];

    return ChatThreadModel(
      channel: json['channel']?.toString() ?? '',
      messages: messages
          .whereType<Map<String, dynamic>>()
          .map(ChatMessageModel.fromJson)
          .toList(),
    );
  }
}
